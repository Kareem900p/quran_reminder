import 'package:prayer_times/prayer_times.dart';
import 'package:geolocator/geolocator.dart';

class PrayerTimesService {
  late PrayerTimes _prayerCalculator;
  DateTime fajr = DateTime.now();
  DateTime dhuhr = DateTime.now();
  DateTime asr = DateTime.now();
  DateTime maghrib = DateTime.now();
  DateTime isha = DateTime.now();

  Future<void> initialize() async {
    final position = await Geolocator.getCurrentPosition();
    _prayerCalculator = PrayerTimes(
      latitude: position.latitude,
      longitude: position.longitude,
      calculationMethod: CalculationMethod.MWL(),
    );
    _updatePrayerTimes();
  }

  void _updatePrayerTimes() {
    fajr = _prayerCalculator.fajr!;
    dhuhr = _prayerCalculator.dhuhr!;
    asr = _prayerCalculator.asr!;
    maghrib = _prayerCalculator.maghrib!;
    isha = _prayerCalculator.isha!;
  }

  List<DateTime> get allPrayers => [fajr, dhuhr, asr, maghrib, isha];
}