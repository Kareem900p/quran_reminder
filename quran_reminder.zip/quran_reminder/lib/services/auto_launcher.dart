import 'package:android_intent_plus/android_intent.dart';

class AutoLauncher {
  static void launchApp() {
    const AndroidIntent intent = AndroidIntent(
      action: 'android.intent.action.MAIN',
      category: 'android.intent.category.LAUNCHER',
      package: 'com.example.quran_reminder',
    );
    intent.launch();
  }
}