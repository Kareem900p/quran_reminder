import 'package:flutter/material.dart';
import '../models/prayer_task.dart';

class PrayerTaskItem extends StatelessWidget {
  final PrayerTask task;
  
  const PrayerTaskItem({super.key, required this.task});

  @override
  Widget build(BuildContext context) {
    return ListTile(
      leading: Icon(
        task.isCompleted ? Icons.check_circle : Icons.access_time,
        color: task.isCompleted ? Colors.green : Colors.orange,
      ),
      title: Text(task.prayerName),
      subtitle: Text('الوقت المحدد: ${task.timeFormatted}'),
      trailing: Text(
        task.isCompleted ? 'مكتمل' : 'متبقي: ${_calculateRemainingTime()}',
        style: TextStyle(
          color: task.isCompleted ? Colors.green : Colors.red,
        ),
      ),
    );
  }

  String _calculateRemainingTime() {
    final now = DateTime.now();
    final remaining = task.scheduledTime.difference(now);
    return '${remaining.inHours} س ${remaining.inMinutes.remainder(60)} د';
  }
}