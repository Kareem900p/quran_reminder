import 'package:flutter/material.dart';
import 'package:intl/intl.dart';

class PrayerCountdown extends StatefulWidget {
  final DateTime prayerTime;
  
  const PrayerCountdown({super.key, required this.prayerTime});

  @override
  State<PrayerCountdown> createState() => _PrayerCountdownState();
}

class _PrayerCountdownState extends State<PrayerCountdown> {
  late Duration _remainingTime;

  @override
  void initState() {
    super.initState();
    _remainingTime = widget.prayerTime.difference(DateTime.now());
    _startTimer();
  }

  void _startTimer() {
    Timer.periodic(const Duration(seconds: 1), (timer) {
      setState(() {
        _remainingTime = widget.prayerTime.difference(DateTime.now());
      });
    });
  }

  @override
  Widget build(BuildContext context) {
    return ListTile(
      title: Text('الوقت المتبقي لصلاة الظهر'),
      subtitle: Text('${_remainingTime.inHours} ساعات ${_remainingTime.inMinutes.remainder(60)} دقائق'),
    );
  }
}