import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:provider/provider.dart';
import '../services/prayer_times_service.dart';
import '../widgets/prayer_task_item.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) {
      Provider.of<PrayerTimesService>(context, listen: false).initialize();
    });
  }

  @override
  Widget build(BuildContext context) {
    final prayerService = Provider.of<PrayerTimesService>(context);
    return Scaffold(
      appBar: AppBar(
        title: Column(
          children: [
            Text(DateFormat('EEEE, d MMMM y', 'ar').format(DateTime.now())),
            Text(DateFormat('dd MMMM yyyy', 'ar').format(DateTime.now()),
          ],
        ),
      ),
      body: ListView.builder(
        itemCount: prayerService.allPrayers.length,
        itemBuilder: (context, index) => PrayerTaskItem(
          task: PrayerTask(
            prayerName: _getPrayerName(index),
            scheduledTime: prayerService.allPrayers[index],
          ),
        ),
      ),
    );
  }

  String _getPrayerName(int index) {
    switch (index) {
      case 0: return 'الفجر';
      case 1: return 'الظهر';
      case 2: return 'العصر';
      case 3: return 'المغرب';
      case 4: return 'العشاء';
      default: return '';
    }
  }
}