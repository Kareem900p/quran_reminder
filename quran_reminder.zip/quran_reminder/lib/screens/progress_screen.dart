import 'package:flutter/material.dart';
import 'package:hive/hive.dart';
import 'package:syncfusion_flutter_charts/charts.dart';

class ProgressScreen extends StatelessWidget {
  const ProgressScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final progressBox = Hive.box('progress');
    return Scaffold(
      appBar: AppBar(title: const Text('تقدمك')),
      body: Column(
        children: [
          _StatsOverview(),
          _PrayerHistoryTable(),
          _ProgressChart(),
        ],
      ),
    );
  }
}

class _ProgressChart extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return SfCircularChart(
      series: <CircularSeries>[
        PieSeries<Map<String, dynamic>, String>(
          dataSource: Hive.box('progress').values.toList(),
          xValueMapper: (data, _) => data['date'],
          yValueMapper: (data, _) => data['completed'],
        )
      ],
    );
  }
}