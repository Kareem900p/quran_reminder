import 'package:flutter/material.dart';
import 'package:hive/hive.dart';

class SettingsScreen extends StatefulWidget {
  const SettingsScreen({super.key});

  @override
  State<SettingsScreen> createState() => _SettingsScreenState();
}

class _SettingsScreenState extends State<SettingsScreen> {
  final _settingsBox = Hive.box('settings');

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('الإعدادات')),
      body: ListView(
        children: [
          _LocationSettings(),
          _NotificationSettings(),
          _HijriAdjustment(),
          _GracePeriodSlider(),
          const Divider(),
          _AppVersion(),
        ],
      ),
    );
  }

  Widget _GracePeriodSlider() {
    return Slider(
      value: _settingsBox.get('gracePeriod', defaultValue: 30.0),
      min: 0,
      max: 60,
      divisions: 6,
      label: 'فترة السماح: ${_settingsBox.get('gracePeriod')} دقيقة',
      onChanged: (value) => _settingsBox.put('gracePeriod', value),
    );
  }
}