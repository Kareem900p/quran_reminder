import 'package:flutter/material.dart';
import 'package:hive/hive.dart';
import '../models/prayer_task.dart';

class TasksScreen extends StatefulWidget {
  const TasksScreen({super.key});

  @override
  State<TasksScreen> createState() => _TasksScreenState();
}

class _TasksScreenState extends State<TasksScreen> {
  final _tasksBox = Hive.box<PrayerTask>('tasks');

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('مهام اليوم')),
      body: ListView.builder(
        itemCount: _tasksBox.length,
        itemBuilder: (context, index) => _TaskItem(_tasksBox.getAt(index)!),
      ),
    );
  }
}

class _TaskItem extends StatelessWidget {
  final PrayerTask task;
  
  const _TaskItem(this.task);

  @override
  Widget build(BuildContext context) {
    return Card(
      color: task.isCompleted ? Colors.green[100] : null,
      child: CheckboxListTile(
        title: Text(task.prayerName),
        subtitle: Text(task.timeFormatted),
        value: task.isCompleted,
        onChanged: (value) => task.toggleCompleted(),
      ),
    );
  }
}