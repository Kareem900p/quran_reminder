import 'package:flutter/material.dart';
import 'package:hive_flutter/hive_flutter.dart';
import 'package:intl/intl.dart';
import 'package:provider/provider.dart';
import 'package:quran_reminder/models/prayer_task.dart';
import 'package:quran_reminder/screens/progress_screen.dart';
import 'package:quran_reminder/screens/settings_screen.dart';
import 'package:quran_reminder/screens/tasks_screen.dart';
import 'package:quran_reminder/services/notification_service.dart';
import 'package:quran_reminder/services/prayer_times_service.dart';
import 'package:geolocator/geolocator.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();

  // تهيئة Hive وقاعدة البيانات
  await Hive.initFlutter();
  Hive.registerAdapter(PrayerTaskAdapter());
  await Hive.openBox<PrayerTask>('tasks');
  await Hive.openBox('settings');
  await Hive.openBox('progress');

  // طلب صلاحيات الموقع
  await _requestLocationPermission();
  
  // تهيئة الخدمات
  await NotificationService().init();
  final prayerService = PrayerTimesService();
  await prayerService.initialize();

  runApp(
    MultiProvider(
      providers: [
        ChangeNotifierProvider.value(value: prayerService),
      ],
      child: const QuranApp(),
    ),
  );
}

class QuranApp extends StatelessWidget {
  const QuranApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'تذكير القرآن',
      theme: _buildTheme(),
      routes: {
        '/': (context) => const HomeScreen(),
        '/tasks': (context) => const TasksScreen(),
        '/progress': (context) => const ProgressScreen(),
        '/settings': (context) => const SettingsScreen(),
      },
      initialRoute: '/',
    );
  }

  ThemeData _buildTheme() {
    return ThemeData(
      fontFamily: 'Uthmanic',
      primaryColor: const Color(0xFF1A5D5A),
      colorScheme: ColorScheme.fromSwatch(
        primarySwatch: Colors.blue,
        accentColor: const Color(0xFFD4AF37),
      ),
      appBarTheme: const AppBarTheme(
        backgroundColor: Color(0xFF1A5D5A),
        titleTextStyle: TextStyle(
          color: Colors.white,
          fontSize: 20,
          fontFamily: 'Uthmanic',
        ),
      ),
    );
  }
}

class HomeScreen extends StatelessWidget {
  const HomeScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: _buildAppBarTitle(),
        actions: [_buildSettingsButton(context)],
      ),
      body: _buildPrayerList(),
      bottomNavigationBar: _buildBottomNavBar(context),
    );
  }

  Widget _buildAppBarTitle() {
    return Column(
      children: [
        Text(DateFormat('EEEE, d MMMM y', 'ar').format(DateTime.now())),
        Text(DateFormat('dd MMM yyyy', 'ar').format(DateTime.now())),
      ],
    );
  }

  Widget _buildSettingsButton(BuildContext context) {
    return IconButton(
      icon: const Icon(Icons.settings),
      onPressed: () => Navigator.pushNamed(context, '/settings'),
    );
  }

  Widget _buildPrayerList() {
    return Consumer<PrayerTimesService>(
      builder: (context, prayerService, _) {
        if (prayerService.allPrayers.isEmpty) {
          return const Center(child: CircularProgressIndicator());
        }
        return ListView.builder(
          itemCount: prayerService.allPrayers.length,
          itemBuilder: (context, index) => _PrayerListItem(
            prayerName: _getPrayerName(index),
            time: prayerService.allPrayers[index],
          ),
        );
      },
    );
  }

  Widget _buildBottomNavBar(BuildContext context) {
    return BottomNavigationBar(
      items: const [
        BottomNavigationBarItem(icon: Icon(Icons.home), label: 'الرئيسية'),
        BottomNavigationBarItem(icon: Icon(Icons.task), label: 'المهام'),
        BottomNavigationBarItem(icon: Icon(Icons.bar_chart), label: 'التقدم'),
      ],
      currentIndex: 0,
      onTap: (index) => _handleNavTap(context, index),
    );
  }

  void _handleNavTap(BuildContext context, int index) {
    switch (index) {
      case 0:
        Navigator.pushNamed(context, '/');
        break;
      case 1:
        Navigator.pushNamed(context, '/tasks');
        break;
      case 2:
        Navigator.pushNamed(context, '/progress');
        break;
    }
  }

  String _getPrayerName(int index) {
    const prayers = ['الفجر', 'الظهر', 'العصر', 'المغرب', 'العشاء'];
    return prayers[index];
  }
}

class _PrayerListItem extends StatelessWidget {
  final String prayerName;
  final DateTime time;

  const _PrayerListItem({required this.prayerName, required this.time});

  @override
  Widget build(BuildContext context) {
    return ListTile(
      leading: const Icon(Icons.access_time, color: Color(0xFF1A5D5A)),
      title: Text(prayerName, style: const TextStyle(fontSize: 18)),
      subtitle: Text(DateFormat.Hm().format(time)),
      trailing: const Icon(Icons.arrow_forward_ios, size: 16),
      onTap: () => _navigateToTasks(context),
    );
  }

  void _navigateToTasks(BuildContext context) {
    Navigator.pushNamed(context, '/tasks');
  }
}

Future<void> _requestLocationPermission() async {
  final status = await Geolocator.checkPermission();
  if (status == LocationPermission.denied) {
    await Geolocator.requestPermission();
  }
}