import 'package:hive/hive.dart';

part 'prayer_task.g.dart';

@HiveType(typeId: 0)
class PrayerTask {
  @HiveField(0)
  final String prayerName;
  
  @HiveField(1)
  final DateTime scheduledTime;
  
  @HiveField(2)
  bool isCompleted;

  PrayerTask({
    required this.prayerName,
    required this.scheduledTime,
    this.isCompleted = false,
  });

  String get timeFormatted => '${scheduledTime.hour}:${scheduledTime.minute}';
  
  void toggleCompleted() => isCompleted = !isCompleted;
}