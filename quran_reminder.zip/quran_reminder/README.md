# تطبيق تذكير القرآن 🕌

تطبيق يساعدك على حفظ 4 صفحات من القرآن بعد كل صلاة.

## الميزات ✨
- تذكير تلقائي عند كل صلاة
- تتبع التقدم اليومي
- إحصائيات مفصلة
- دعم الهجري والميلادي

## التثبيت 📲
1. انسخ المشروع:
   ```bash
   git clone https://github.com/yourusername/quran-reminder.git
   ```
2. ثبّت التبعيات:
   ```bash
   flutter pub get
   ```
3. شغّل التطبيق:
   ```bash
   flutter run
   ```

## الصلاحيات المطلوبة 🔒
- الوصول إلى الموقع (لحساب أوقات الصلاة)
- الإشعارات (للتذكير بالصلوات)

## بناء APK ⚙️
```bash
flutter build apk --release
```

## المساهمة 🤝
المساهمات مرحب بها! اتبع الخطوات:
1. انشئ Fork للمشروع
2. أنشئ فرعًا جديدًا (`git checkout -b feature/new-feature`)
3. أضف التغييرات وأرسلها (`git commit -am 'Add new feature'`)
4. ادفع إلى الفرع (`git push origin feature/new-feature`)
5. أنشئ Pull Request